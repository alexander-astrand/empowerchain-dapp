mod error;
mod execute;
mod msg;
mod query;
mod state;

use cosmwasm_std::entry_point;
use cosmwasm_std::{ DepsMut, Env, MessageInfo, Response};
use crate::error::ContractError;
use crate::msg::InstantiateMsg;
use crate::state::save_state;
use crate::state::State;


#[entry_point]
pub fn instantiate(
    deps: DepsMut,
    _env: Env,
    _info: MessageInfo,
    msg: InstantiateMsg,
) -> Result<Response, ContractError> {
    let state = State {
        public_key: msg.public_key,
        admin_address: msg.admin_address,
        token_count: 0,
    };
    save_state(deps.storage, &state)?;
    Ok(Response::new().add_attribute("method", "instantiate"))
}
